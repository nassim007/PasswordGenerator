package com.example.passwordgenerator.models.password.contents

data class CustomPwdContent(override var content: String = "?!$%*@&#") : PasswordContent


